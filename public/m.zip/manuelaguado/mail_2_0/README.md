# mail_2_0
Envío de mails con soporte para plantillas , librería para Framedev


##USO:

        -Instalamos pear
            sudo apt-get install php-pear
    
        -Instalamos las librerias de pear necesarias
            sudo pear install mail
            sudo pear install Net_SMTP
            sudo pear install mail_mime
